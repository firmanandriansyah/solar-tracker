Individual Placements per board: 4

Number of Parts: 8


Board size is 2.15 x 1.90 inches (54.61 x 48.26 mm)

