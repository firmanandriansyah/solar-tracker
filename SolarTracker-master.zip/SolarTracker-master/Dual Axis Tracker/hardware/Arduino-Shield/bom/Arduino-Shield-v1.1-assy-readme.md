Individual Placements per board: 4

Number of Parts: 8


Board size is 1.49 x 2.09 inches (37.85 x 53.09 mm)

