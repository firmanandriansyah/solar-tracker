Individual Placements per board: 2

Number of Parts: 5


Board size is 1.15 x 1.60 inches (29.21 x 40.64 mm)

