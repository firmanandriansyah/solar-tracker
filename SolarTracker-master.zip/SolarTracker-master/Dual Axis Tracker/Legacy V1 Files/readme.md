# Smart Tracker V1

Old version of our smart tracker.  Uses entirely 1/4th inch wood.  Electronics is a jumble.  

If you want to make this read the PDF write up.
