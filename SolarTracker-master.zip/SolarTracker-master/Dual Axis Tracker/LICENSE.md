All rights reserved to Brown Dog Gadgets.
